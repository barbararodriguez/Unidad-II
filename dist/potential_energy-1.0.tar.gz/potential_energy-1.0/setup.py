from setuptools import setup
setup(
    name='potential_energy',
    version='1.0',
    description='This module calculate potential_energy',
    author='BRL',
    author_email="barbara09rodriguez@gmail.com",
    url='http://www.utng.edu.mx',
    py_modules=['potential_energy']

    
)